<html>
<head>
<title>Exercise 4-1</title>
</head>
<body>
<h1>Regular HTML section (outside  tags)</h1>
<p>You can type regular HTML here and it will show up</p>

<h1>PHP section (inside  tags)</h1>
This was output using PHP<br></body>
</html>