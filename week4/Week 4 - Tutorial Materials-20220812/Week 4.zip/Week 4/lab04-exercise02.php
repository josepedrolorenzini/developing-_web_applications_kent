<html>
<head>
<title>Exercise 4-2</title>
</head>
<body>
<h1>Simple Calendar using Loops</h1>

<table border=1>
<tr>
  <th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th>
</tr>

</table>


</body>
</html>
